package com.cts.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/consumer")
public class AdminConsumer {

	
	@GetMapping("/getConsume") //http://localhost:2020/consumer/getConsume
	public String consumingProviderService() {
		
		RestTemplate restTemplate = new RestTemplate();
		String providerUrl="http://localhost:2021/provider/hello";
		//String providerUrl="http://ADMIN-PROVIDER/provider/hello";
		String consumerResult= restTemplate.getForObject(providerUrl,String.class);
		return "From Consumer Consuming the Provider Service : "+consumerResult;
	}
	
	
	
}
