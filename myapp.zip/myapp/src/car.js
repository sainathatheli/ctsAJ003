//props to read the arguments which assigned to Components
function Car(props){

   return(<div>
            <h1>we are in Car functional Component</h1>
            <p>Car brand name reading using props keyword : { props.brand }</p>
   </div>);
}

export  default Car;