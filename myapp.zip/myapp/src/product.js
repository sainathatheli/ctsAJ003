//Components are two types in react 1)funtional component state-less and 2)Class Component is state-full
//1.example on functional component
function Product(){
    return(<div>
           <h1>welcome to product functional component</h1>
    </div>)
}

export default Product;
