//Class Component we can define the login in render()

import React from 'react';
class Employee extends  React.Component{


     render(){
         return <h1>welcome to class component </h1>;
     }


}

export default Employee;