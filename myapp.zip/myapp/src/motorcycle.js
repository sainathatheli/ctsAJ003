import React from 'react';

class MotorCycle extends React.Component{

    constructor(props){
        super(props)
        this.state={
            msg:"Hello, from Cts "
        }
    }

   render(){
       return(<div>
                 <h1>MotorCycle  Class Component</h1>
                 <p>MotoCycle Name reading using props : {this.props.mname} </p>
                 <p>{this.state.msg}</p>
       </div>);
   }
}

export default MotorCycle;