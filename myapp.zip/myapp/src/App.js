import logo from './logo.svg';
import './App.css';
import Product from './product';
import Employee from './employee';
import Car from './car';
import MotorCycle from './motorcycle';

function App() {
  return (
    <div className="App">
        <h1>welcome to setting up react application</h1>
        <p>weclome to reactjs</p>
        <hr></hr>
        <div>
        <Product></Product>   
        </div>  
        <hr></hr>
         <Employee></Employee>
         <hr></hr>
          <Car brand="Kiamotors"  ></Car>
          <hr></hr>
          <MotorCycle mname="Hero"></MotorCycle>
    </div>
  );
}

export default App;
