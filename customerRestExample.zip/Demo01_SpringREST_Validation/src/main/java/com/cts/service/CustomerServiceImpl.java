package com.cts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cts.dto.CustomerDTO;

import com.cts.entity.Customer;
import com.cts.exception.CtsBankException;
import com.cts.repository.CustomerRespository;

@Service(value = "customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRespository customerRespository;

	@Override
	public CustomerDTO getCustomer(Integer customerId) throws CtsBankException {
		Optional<Customer> optional = customerRespository.findById(customerId);
		Customer customer = optional.orElseThrow(() -> new CtsBankException("Service.CUSTOMER_NOT_FOUND"));
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(customer.getCustomerId());
		customerDTO.setDateOfBirth(customer.getDateOfBirth());
		customerDTO.setEmailId(customer.getEmailId());
		customerDTO.setName(customer.getName());
		
		return customerDTO;
	}

	@Override
	public Integer addCustomer(CustomerDTO customerDTO) throws CtsBankException {
		Customer customer = new Customer();
		customer.setDateOfBirth(customerDTO.getDateOfBirth());
		customer.setEmailId(customerDTO.getEmailId());
		customer.setName(customerDTO.getName());
		customer.setCustomerId(customerDTO.getCustomerId());
		customerRespository.save(customer);
		return customer.getCustomerId();
	}

	@Override
	public void updateCustomer(Integer customerId, String emailId) throws CtsBankException {
		Optional<Customer> customer = customerRespository.findById(customerId);
		Customer c = customer.orElseThrow(() -> new CtsBankException("Service.CUSTOMER_NOT_FOUND"));
		c.setEmailId(emailId);
	}

	@Override
	public void deleteCustomer(Integer customerId) throws CtsBankException {
		Optional<Customer> customer = customerRespository.findById(customerId);
		customer.orElseThrow(() -> new CtsBankException("Service.CUSTOMER_NOT_FOUND"));
		customerRespository.deleteById(customerId);
	}

	@Override
	public List<CustomerDTO> getAllCustomers() throws CtsBankException {
		Iterable<Customer> customers = customerRespository.findAll();
		List<CustomerDTO> customerDTOs = new ArrayList<>();
		customers.forEach(customer -> {
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(customer.getCustomerId());
			customerDTO.setDateOfBirth(customer.getDateOfBirth());
			customerDTO.setEmailId(customer.getEmailId());
			customerDTO.setName(customer.getName());
			customerDTOs.add(customerDTO);
		});
		if (customerDTOs.isEmpty())
			throw new CtsBankException("Service.CUSTOMERS_NOT_FOUND");
		return customerDTOs;
	}

}
