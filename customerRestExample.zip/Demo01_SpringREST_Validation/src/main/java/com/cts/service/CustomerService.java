package com.cts.service;

import java.util.List;

import com.cts.dto.CustomerDTO;
import com.cts.exception.CtsBankException;



public interface CustomerService {
	public Integer addCustomer(CustomerDTO customerDTO) throws CtsBankException;
	public CustomerDTO getCustomer(Integer customerId) throws CtsBankException;
	public void updateCustomer(Integer customerId, String emailId)throws CtsBankException;
	public void deleteCustomer(Integer customerId)throws CtsBankException;
	public List<CustomerDTO> getAllCustomers() throws CtsBankException;
}
