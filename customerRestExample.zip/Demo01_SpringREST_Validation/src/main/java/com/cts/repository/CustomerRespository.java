package com.cts.repository;


import org.springframework.data.repository.CrudRepository;

import com.cts.entity.Customer;

public interface CustomerRespository extends CrudRepository<Customer, Integer> {

}
