package com.cts.exception;

public class CtsBankException extends Exception {

	private static final long serialVersionUID = 1L;

	public CtsBankException(String message) {
		super(message);
		
	}
	
}
