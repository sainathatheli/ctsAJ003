package com.cts.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Product;
import com.cts.exception.InvalidProductException;
import com.cts.service.ProductServiceImpl;

@RestController
@RequestMapping("/products")
@Validated
public class ProductAPI {     //http://localhost:8005/products/pdetails

	@Autowired
	ProductServiceImpl productSImpl; //has-a relation
	
	@Autowired
	private Environment environment;
	
	@GetMapping("/pdetails")
	public List<Product> getProductDetails(){
		
		return productSImpl.getProductDetails();
	}
	                         //http://localhost:8005/products/delete/4
	@DeleteMapping("/delete/{id}")   //{} pathvariable
	public ResponseEntity<String> deleteProduct(@PathVariable int id) throws InvalidProductException {
		productSImpl.deleteProductById(id);
		String successMessage=environment.getProperty("API.DELETE_SUCCESS");
		return new ResponseEntity<String>(successMessage,HttpStatus.OK);
	}
	
	@GetMapping("/search/{id}") //http://locahost:8005/products/search/3
	public ResponseEntity<Product> getProductById(@PathVariable @Min(value = 1,message = "in id path variable range from 1 to 100") 
	                                          @Max(value = 100,message = "PathVariable Pid max value is 100") int id) throws InvalidProductException {
		Product pobj= productSImpl.findProductById(id);
		return new ResponseEntity<>(pobj,HttpStatus.OK);
	}
	
	@PostMapping("/add") //http://localhost:8005/products/add
	public String addProduct(@Valid @RequestBody Product p) {
		return productSImpl.addProduct(p);
	}
	
	@PutMapping("/update") //http://localhost:8005/products/update/
	public String updateProduct(@RequestBody Product p) {
		return productSImpl.updateProduct(p);
	}

}
