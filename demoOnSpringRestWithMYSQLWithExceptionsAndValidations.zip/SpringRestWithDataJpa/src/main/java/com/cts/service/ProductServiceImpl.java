package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Product;
import com.cts.exception.InvalidProductException;
import com.cts.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
    @Autowired 
    ProductRepository productRepo;//has-relation
	
	@Override
	public List<Product> getProductDetails() {
		// TODO Auto-generated method stub
		  return productRepo.findAll();
	}

	@Override
	public void deleteProductById(int id) throws InvalidProductException {
		String msg="";
		// TODO Auto-generated method stub
		//first check the record exist or not
		 Optional<Product> optional=productRepo.findById(id);
		 optional.orElseThrow(()->new InvalidProductException("Service.PROUDCT_NOT_FOUND"));
	     productRepo.deleteById(id); //delete the record
	}

	@Override
	public Product findProductById(int id) throws InvalidProductException {
		 Optional<Product> optional=productRepo.findById(id);
        
		 Product p = optional.orElseThrow(
				   ()-> new InvalidProductException("Service.PROUDCT_NOT_FOUND"));
		 return p; 
	}

	@Override
	public String addProduct(Product p) {
		
		Product product =productRepo.save(p);
		return product.getPid()+ " Record is inserted";
			
	}

	@Override
	public String updateProduct(Product p) {
		// TODO Auto-generated method stub
		String msg="";
		Optional<Product> optional=productRepo.findById(p.getPid());
		if(optional.isPresent()) {
			productRepo.save(p);//save method based on id record exist it will update
			                    // if not then it will perform insert
			msg="Record is successfully updated";
		}else {
			 msg="Record is not Found";
		}
		return msg;
	}
	
	
	
	

}
