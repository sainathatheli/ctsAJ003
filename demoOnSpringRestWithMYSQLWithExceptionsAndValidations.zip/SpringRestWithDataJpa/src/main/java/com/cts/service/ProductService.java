package com.cts.service;

import java.util.List;

import com.cts.entity.Product;
import com.cts.exception.InvalidProductException;

public interface ProductService {

	public List<Product> getProductDetails();//getall records
	public void deleteProductById(int id)throws InvalidProductException;//delete
	public Product findProductById(int id)throws InvalidProductException;//search
	public String addProduct(Product p);//add
	public String updateProduct(Product p);
	
	
}
