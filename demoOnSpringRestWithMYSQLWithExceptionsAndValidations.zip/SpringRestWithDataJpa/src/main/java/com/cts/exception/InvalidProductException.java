package com.cts.exception;

public class InvalidProductException extends Exception{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidProductException(String message) {
		// TODO Auto-generated constructor stub	 
		  super(message);
		 
	}
	
}
