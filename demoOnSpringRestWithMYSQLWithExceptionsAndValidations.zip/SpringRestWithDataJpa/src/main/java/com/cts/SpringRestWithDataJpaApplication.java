package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestWithDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestWithDataJpaApplication.class, args);
	}

}
