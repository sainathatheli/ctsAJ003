create database cts;

use cts;

create table product(
   pid int primary key,
   pname varchar(30),
   price decimal(10,2));
   
 
insert into product values(1,'mouse',400);
insert into product values(2,'keyboard',800);
insert into product values(3,'ram',3000);
insert into product values(4,'monitor',5000);
insert into product values(5,'laptop',30000);  