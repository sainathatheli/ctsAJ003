package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Product;
import com.cts.service.ProductServiceImpl;

@RestController
@RequestMapping("/products")
public class ProductAPI {     //http://localhost:8005/products/pdetails

	@Autowired
	ProductServiceImpl productSImpl; //has-a relation
	
	@GetMapping("/pdetails")
	public List<Product> getProductDetails(){
		
		return productSImpl.getProductDetails();
	}
	                         //http://localhost:8005/products/delete/4
	@DeleteMapping("/delete/{id}")   //{} pathvariable
	public String deleteProduct(@PathVariable int id) {
		return productSImpl.deleteProductById(id);
	}
	
	@GetMapping("/search/{id}") //http://locahost:8005/products/search/3
	public Product getProductById(@PathVariable int id) {
		return productSImpl.findProductById(id);
	}
	
	@PostMapping("/add") //http://localhost:8005/products/add
	public String addProduct(@RequestBody Product p) {
		return productSImpl.addProduct(p);
	}
	

}
