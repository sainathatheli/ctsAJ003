package com.cts.service;

import java.util.List;

import com.cts.entity.Product;

public interface ProductService {

	public List<Product> getProductDetails();//getall records
	public String deleteProductById(int id);//delete
	public Product findProductById(int id);//search
	public String addProduct(Product p);//add
	
}
