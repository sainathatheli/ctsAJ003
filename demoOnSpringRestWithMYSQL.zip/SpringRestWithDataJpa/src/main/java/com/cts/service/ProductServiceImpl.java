package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Product;
import com.cts.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
    @Autowired 
    ProductRepository productRepo;//has-relation
	
	@Override
	public List<Product> getProductDetails() {
		// TODO Auto-generated method stub
		  return productRepo.findAll();
	}

	@Override
	public String deleteProductById(int id) {
		String msg="";
		// TODO Auto-generated method stub
		//first check the record exist or not
		 Optional<Product> optional=productRepo.findById(id);
		  if(optional.isPresent()) {
			  productRepo.deleteById(id);//delete the record
			  msg="Record is deleted : "+id;
		  }else {
			  msg="Record is not found";
		  }
		  
		  return msg;
	}

	@Override
	public Product findProductById(int id) {
		 Optional<Product> optional=productRepo.findById(id);
         return optional.get();
	}

	@Override
	public String addProduct(Product p) {
		
		Product product =productRepo.save(p);
		return product.getPid()+ " Record is inserted";
			
	}
	
	
	
	

}
