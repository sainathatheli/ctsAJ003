package com.cts.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/provider")
public class AdminProvider {

	@GetMapping("/hello")    //http://localhost:2019/provider/hello  --endpoint url of service
	public String getMsg() {
		return "From Provider RestAPI Class";
	}
	
}
